In the documents folder, you will find our Game Anaylsis document and art assets/concepts.
In the build folder, you will find our final product of the Classic Game Challenge, "Devilman."


To play, navigate through the build folder to find the Unity.exe file.

or

copy/paste this URL and download the game:
https://sbyer.itch.io/devilman

URL to GitHub Repository:
https://github.com/ewhite755/Pac-Man